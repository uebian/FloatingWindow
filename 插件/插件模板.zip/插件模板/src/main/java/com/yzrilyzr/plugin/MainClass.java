package com.yzrilyzr.plugin;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;
import com.yzrilyzr.floatingwindow.pluginapi.API;
import com.yzrilyzr.floatingwindow.pluginapi.Window;

public class MainClass implements Window.WindowInterface
{

	private Context ctx;
	//必须实现的构造器
	//Context是主程序的Context,Intent是从MainActivity启动并发过来的
	public MainClass(Context c,Intent e){
		//使用ProxyApi
		ctx=c;
		Window w=new Window(c,-2,API.px(300))
		.setTitle("title")
		.setWindowInterface(this)
		.show();
		//只能用这种方式载入xml中的layout
		//xml可以使用com.yzrilyzr.ui包
		//包名为插件的包名，路径是xml在apk中的路径
		View v=API.parseXmlViewFromFile(ctx,"com.yzrilyzr.plugin","res/layout/main.xml");
		w.addView(v);
	}
	//实现的接口
	@Override
	public void onSizeChanged(int p1, int p2, int p3, int p4)
	{
		// TODO: Implement this method
	}
	@Override
	public void onPositionChanged(int p1, int p2)
	{
		// TODO: Implement this method
	}
	@Override
	public void onButtonDown(int p1)
	{
		Toast.makeText(ctx,"Code:"+p1,0).show();
	}
}
